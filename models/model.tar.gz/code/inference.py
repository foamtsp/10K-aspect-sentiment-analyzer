
import json, pickle
from pathlib import Path
import numpy as np
import xgboost as xgb

def model_fn(model_dir):
    root = Path(model_dir)
    booster = xgb.XGBClassifier()
    booster.load_model(root / "booster.json")
    with open(root / "calibrator.pkl", "rb") as f:
        calibrator = pickle.load(f)
    with open(root / "feature_cols.json") as f:
        cols = json.load(f)
    return {"booster": booster, "calibrator": calibrator, "cols": cols}

def input_fn(body, content_type):
    if content_type != "application/json":
        raise ValueError(content_type)
    p = json.loads(body)
    return p["features"]

def predict_fn(features, bundle):
    cols = bundle["cols"]
    if isinstance(features, dict):
        X = np.array([[float(features[c]) for c in cols]])
    else:
        X = np.asarray(features, dtype=float)
    proba = bundle["calibrator"].predict_proba(X)[:, 1]
    return {"probability_up": proba.tolist()}

def output_fn(pred, accept):
    return json.dumps(pred), "application/json"
